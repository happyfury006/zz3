#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include <fstream>
using namespace std;

const int nbmax_sommet = 30;
const int nbmax_succ = 5;
const int c_infini = 1000;

typedef struct t_sommet
{
	int ns;
	int succ[nbmax_succ];
	int distance[nbmax_succ];
}t_sommet;

typedef struct t_graphe {
	int n;
	t_sommet liste[nbmax_sommet];
}t_graphe;

typedef struct t_liste_parcours {
	int n;
	int liste[nbmax_sommet];
}t_liste_parcours;

typedef struct t_solution {
	int destination;
	int date[nbmax_sommet];
	int pere[nbmax_sommet];
}t_solution;

void plus_court_chemin(t_graphe un_graphe, t_solution& une_solution, int depart, int destionation);

t_solution bellmann(t_graphe un_graphe, int depart, int arrive);

void lire_fichier(t_graphe& un_graphe);

#endif // !HEADER_H

