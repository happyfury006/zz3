#include <iostream>
#include "Header.h"
using namespace std;

int main()
{
	std::cout << "Hello World!\n";

	t_graphe g;
	t_solution ma_solution;

	/*g.n = 9;
	g.liste[1].ns = 2;
	g.liste[1].succ[1] = 4;
	g.liste[1].distance[1] = 4;
	g.liste[1].succ[2] = 2;
	g.liste[1].distance[2] = 10;
	g.liste[2].ns = 2;
	g.liste[2].succ[1] = 3;
	g.liste[2].distance[1] = 1;
	g.liste[2].succ[2] = 5;
	g.liste[2].distance[2] = 2;
	g.liste[3].ns = 2;
	g.liste[3].succ[1] = 6;
	g.liste[3].distance[1] = 4;
	g.liste[3].succ[2] = 8;
	g.liste[3].distance[2]=2;
	g.liste[4].ns = 1;
	g.liste[4].succ[1] = 6;
	g.liste[4].distance[1] = 12;
	g.liste[5].ns = 2;
	g.liste[5].succ[1] = 3;
	g.liste[5].distance[1] = 9;
	g.liste[5].succ[2] = 8;
	g.liste[5].distance[2] = 3;
	g.liste[6].ns = 1;
	g.liste[6].succ[1] = 7;
	g.liste[6].distance[1] = 5;
	g.liste[7].ns = 2;
	g.liste[7].succ[1] = 8;
	g.liste[7].distance[1] = 3;
	g.liste[7].succ[2] = 9;
	g.liste[7].distance[2] = 3;
	g.liste[8].ns = 1;
	g.liste[8].succ[1] = 9;
	g.liste[8].distance[1] = 3;
	g.liste[9].ns = 0;
	g.liste[9].distance[1] = 0;
	g.liste[9].succ[1] = 0;*/


	/*plus_court_chemin(g, ma_solution, 1, 9);
	for (int i = 1; i < g.n; i++)
	{
		std::cout << "la date est\n" ;
		std::cout << ma_solution.date[i] << endl;
		std::cout << "le pere est\n";
		std::cout << ma_solution.pere[i] << endl;
	}*/

	lire_fichier(g);

	t_solution sol = bellmann(g, 1, 9);
	std::cout << sol.pere[9] << endl;
	std::cout << sol.pere[8] << endl;
	std::cout << sol.pere[5] << endl;
	std::cout << sol.pere[2] << endl;