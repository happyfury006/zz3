#include "Header.h"


void plus_court_chemin(t_graphe mon_graphe, t_solution& ma_solution, int depart, int destination) {

	memset(&ma_solution, 0, sizeof(ma_solution));
	ma_solution.destination = destination;

	//initialisation

	for (int i = 1; i < mon_graphe.n; i++)
	{
		ma_solution.date[i] = c_infini;
	}
	ma_solution.date[depart] = 0;

	int dejavu[nbmax_sommet];
	for (int i = 1; i <= mon_graphe.n; i++)
	{
		dejavu[i] = 0;
	}

	//

	for (int i = 1; i <= mon_graphe.n; i++)
	{
		//1.rechercher le sommet a traiter j 
		int j;
		int val_min = c_infini;
		for (int k = 1; k <= mon_graphe.n; k++)
		{
			if ((ma_solution.date[k] < val_min) && (dejavu[k] == 0)) {
				val_min = ma_solution.date[k];
				j = k;
			}
		}

		// 2. propager les marques
		int ns = mon_graphe.liste[j].ns;
		for (int k = 1; k <= ns; k++)
		{
			int le_succ = mon_graphe.liste[j].succ[k];
			int cout_arc = mon_graphe.liste[j].distance[k];

			if (ma_solution.date[j] + cout_arc < ma_solution.date[le_succ])
			{
				ma_solution.date[le_succ] = ma_solution.date[j] + cout_arc;
				ma_solution.pere[le_succ] = j;
			}
		}
		dejavu[j] = 1;
	}
}

t_solution bellmann(t_graphe mon_graphe, int depart, int arrive) {

	t_solution sol;
	sol.destination = arrive;

	for (int i = 1; i < mon_graphe.n; i++)
	{
		sol.date[i] = c_infini;
	}
	sol.date[depart] = 0;

	int stop = 0;


	while (stop == 0)
	{
		stop = 1;

		for (int j = 1; j < mon_graphe.n; j++)
		{
			for (int k = 1; k <= mon_graphe.liste[j].ns; k++)
			{
				int su = mon_graphe.liste[j].succ[k];


				if ((sol.date[j] + mon_graphe.liste[j].distance[k]) < sol.date[su])
				{
					sol.date[su] = sol.date[j] + mon_graphe.liste[j].distance[k];
					sol.pere[su] = j;
					stop = 0;
				}
			}
		}



	}



	return sol;
}

void lire_fichier(t_graphe& un_graphe) {
	ifstream fichier("graphe.txt", ios::in); // on ouvre le fichier en lecture
	// a modifier pour que le fichier excel puisse �tre lu 
	if (fichier) // si l'ouverture a r�ussi
	{
		fichier >> un_graphe.n;
		for (int i = 1; i < un_graphe.n; i++)
		{
			fichier >> un_graphe.liste[i].ns;
			for (int j = 1; j < un_graphe.liste[i].ns; j++)
			{
				fichier >> un_graphe.liste[i].succ[j];
				fichier >> un_graphe.liste[i].distance[j];

			}
		}
	}
}
